package com.example.birthdaycard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BirthdayCardScreen()
        }
    }
}

@Composable
fun BirthdayCardScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White) // фон страницы
    ) {
        // Торт по центру
        Image(
            painter = painterResource(id = R.drawable.cake), // фото торта
            contentDescription = "Cake",
            modifier = Modifier
                .size(500.dp)
                .align(Alignment.Center)
        )

        // Текст с надписью "HAPPY BIRTHDAY!" в два ряда
        Column(
            horizontalAlignment = Alignment.CenterHorizontally, // Центрируем по горизонтали
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 150.dp)
        ) {
            Text(
                text = "HAPPY",
                style = TextStyle(
                    color = Color(116, 31, 24, 255),
                    fontSize = 60.sp,
                    fontWeight = FontWeight.Bold, // жирный шрифт
                    letterSpacing = 2.sp
                )
            )
            Text(
                text = "BIRTHDAY!",
                style = TextStyle(
                    color = Color(113, 31, 25, 255),
                    fontSize = 60.sp,
                    fontWeight = FontWeight.Bold, // жирный шрифт
                    letterSpacing = 2.sp
                )
            )
        }

        // Пожелание снизу
        Text(
            text = "Wish you all the best!",
            style = TextStyle(
                color = Color(210, 89, 66, 255),
                fontSize = 30.sp,
                fontFamily = FontFamily.Serif, // шрифт с засечками
                fontWeight = FontWeight.Normal // обычный шрифт
            ),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 170.dp)
        )

        // Конфетти сверху
        Image(
            painter = painterResource(id = R.drawable.confetti),
            contentDescription = "Confetti",
            modifier = Modifier
                .fillMaxSize() // растягиваем на весь экран
                .align(Alignment.TopCenter), // конфетти сверху
            contentScale = ContentScale.Crop // изображение растягиваем без искажения пропорций
        )
    }
}
