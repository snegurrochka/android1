package com.example.wordscramble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.TextFieldValue
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WordScrambleGame()
        }
    }
}

@Composable
fun WordScrambleGame() {
    // Список слов для игры
    val words = listOf("KOTLIN", "COMPOSE", "ANDROID", "SCRAMBLE", "DEVELOPER")

    // Выбираем случайное слово
    val correctWord = remember { mutableStateOf(words.random()) }
    // Перемешиваем это слово
    var scrambledWord by remember { mutableStateOf(scrambleWord(correctWord.value)) }

    // Состояние для ввода пользователя и сообщения
    var userInput by remember { mutableStateOf(TextFieldValue()) }
    var message by remember { mutableStateOf("") }

    // Интерфейс игры
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Guess the Word!", style = TextStyle(fontSize = 32.sp, fontFamily = FontFamily.Serif))
        Spacer(modifier = Modifier.height(20.dp))

        Text(text = "Scrambled: $scrambledWord", style = TextStyle(fontSize = 28.sp, color = Color.Black))

        Spacer(modifier = Modifier.height(20.dp))

        // Поле ввода для ответа
        OutlinedTextField(
            value = userInput,
            onValueChange = { userInput = it },
            label = { Text("Your Guess") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Кнопка для отправки ответа
        Button(onClick = {
            val userAnswer = userInput.text.trim().uppercase()
            println("User input: $userAnswer") // Для отладки
            println("Correct word: ${correctWord.value}") // Для отладки

            // Приводим введённый текст и слово к одному регистру (верхний)
            if (userAnswer == correctWord.value) {
                message = "Correct! Starting new round..."
                // Генерируем новое слово и перемешиваем его
                correctWord.value = words.random()
                scrambledWord = scrambleWord(correctWord.value)
                userInput = TextFieldValue() // очищаем поле ввода
            } else {
                message = "Wrong! Try again!"
            }
        }) {
            Text("Submit")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Выводим сообщение о правильности ответа
        Text(text = message, style = TextStyle(fontSize = 20.sp, color = Color.Gray))
    }
}

// Функция для перемешивания букв в слове
fun scrambleWord(word: String): String {
    val wordList = word.toList()
    val shuffledWord = wordList.shuffled().joinToString("")
    println("Shuffled word: $shuffledWord") // Для отладки
    return shuffledWord
}
